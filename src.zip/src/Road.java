import java.awt.*;

public class Road extends GameObject {
    public Road(int x, int y, int timeElapsed) {
        super(x, y, timeElapsed, 0);
    }

    @Override
    public void draw(Graphics2D graphic2d) {
        // Реализация метода draw для дороги
    }

    @Override
    public void move() {

    }
}