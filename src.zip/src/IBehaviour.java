import javax.swing.*;
import java.awt.*;
import java.util.Random;


public interface IBehaviour {
    void move();
}
